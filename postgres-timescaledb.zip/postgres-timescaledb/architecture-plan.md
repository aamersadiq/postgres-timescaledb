# PostgreSQL TimescaleDB Application Architecture Plan

## Project Overview

This document outlines the architecture for a .NET 8 Web API application that leverages PostgreSQL with TimescaleDB extension to handle transaction data. The application will demonstrate various TimescaleDB features including time-series data analysis, high-volume transaction processing, data retention policies, and TimescaleDB-specific optimizations.

## System Architecture

### High-Level Architecture

```mermaid
graph TD
    Client[Client Applications] --> API[.NET 8 Web API]
    API --> DAL[Data Access Layer]
    DAL --> DB[(PostgreSQL + TimescaleDB)]
    API --> Cache[Response Cache]
```

### Components

1. **Client Applications**: External systems that consume the API
2. **Web API Layer**: .NET 8 RESTful API endpoints
3. **Data Access Layer**: Entity Framework Core with Npgsql provider
4. **Database**: PostgreSQL with TimescaleDB extension running in Docker
5. **Caching Layer**: Optional in-memory or distributed cache for high-performance scenarios

## Database Design

### Transaction Data Model

The core entity will be a `Transaction` with the following properties:

- `Id` (UUID): Unique identifier
- `CreatedAt` (TIMESTAMPTZ): When the transaction occurred (this will be our time dimension)
- `Amount` (DECIMAL): Transaction amount
- `AccountId` (UUID): Reference to the account
- `CategoryId` (UUID): Transaction category
- `Description` (TEXT): Optional description
- `Metadata` (JSONB): Additional flexible properties

### TimescaleDB Hypertable Design

We'll convert the transactions table into a TimescaleDB hypertable partitioned by time:

```sql
SELECT create_hypertable('transactions', 'created_at', 
                         chunk_time_interval => INTERVAL '1 day');
```

This partitioning strategy optimizes for:
- Fast inserts of new transactions
- Efficient queries over specific time ranges
- Better compression of historical data

### Indexing Strategy

- Time-based index on `created_at` (automatically created by TimescaleDB)
- Index on `account_id` for quick account-based lookups
- Composite index on `(account_id, created_at)` for account-specific time range queries
- Optional index on `category_id` depending on query patterns

## API Design

### RESTful Endpoints

#### Transaction Management

- `GET /api/transactions` - List transactions with filtering options
- `GET /api/transactions/{id}` - Get transaction details
- `POST /api/transactions` - Create new transaction
- `PUT /api/transactions/{id}` - Update transaction
- `DELETE /api/transactions/{id}` - Delete transaction

#### Analytics Endpoints

- `GET /api/analytics/daily-summary` - Daily transaction aggregates
- `GET /api/analytics/account/{id}/trends` - Account-specific trends
- `GET /api/analytics/categories/distribution` - Category distribution analysis

### Query Parameters

The API will support various query parameters for time-series data:

- `from` & `to`: Time range filtering
- `interval`: Aggregation interval (hour, day, week, month)
- `account_id`: Filter by account
- `category_id`: Filter by category

## TimescaleDB Features Implementation

### Continuous Aggregates

We'll implement continuous aggregates for common analytical queries:

```sql
CREATE MATERIALIZED VIEW daily_transaction_summary
WITH (timescaledb.continuous) AS
SELECT 
    time_bucket('1 day', created_at) AS bucket,
    account_id,
    count(*) AS transaction_count,
    sum(amount) AS total_amount
FROM transactions
GROUP BY bucket, account_id;
```

### Data Compression

For historical data, we'll implement TimescaleDB's native compression:

```sql
ALTER TABLE transactions SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'account_id',
    timescaledb.compress_orderby = 'created_at'
);

-- Add compression policy (compress data older than 30 days)
SELECT add_compression_policy('transactions', INTERVAL '30 days');
```

### Data Retention Policies

We'll implement automated data management policies:

```sql
-- Example: Keep detailed data for 1 year, then drop
SELECT add_retention_policy('transactions', INTERVAL '1 year');

-- Alternative: Keep detailed data for 3 months, then compress
SELECT add_retention_policy('transactions', INTERVAL '3 months', 
                           if_exists => true);
```

## Data Access Layer

### Entity Framework Core Configuration

We'll use EF Core with the Npgsql provider and the TimescaleDB extension:

```csharp
// DbContext configuration
services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(Configuration.GetConnectionString("DefaultConnection"),
    npgsqlOptions => npgsqlOptions.EnableRetryOnFailure()));
```

### Entity Configuration

```csharp
public class Transaction
{
    public Guid Id { get; set; }
    public DateTime CreatedAt { get; set; }
    public decimal Amount { get; set; }
    public Guid AccountId { get; set; }
    public Guid CategoryId { get; set; }
    public string Description { get; set; }
    public JsonDocument Metadata { get; set; }
    
    // Navigation properties
    public Account Account { get; set; }
    public Category Category { get; set; }
}
```

### Repository Pattern

We'll implement a repository pattern for data access:

```csharp
public interface ITransactionRepository
{
    Task<IEnumerable<Transaction>> GetTransactionsAsync(
        DateTime? from = null, 
        DateTime? to = null,
        Guid? accountId = null);
    
    Task<Transaction> GetByIdAsync(Guid id);
    Task<Transaction> CreateAsync(Transaction transaction);
    // Additional methods...
}
```

## Docker Setup

### Docker Compose Configuration

```yaml
version: '3.8'

services:
  timescaledb:
    image: timescale/timescaledb:latest-pg14
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=transactiondb
    ports:
      - "5432:5432"
    volumes:
      - timescale_data:/var/lib/postgresql/data
    restart: unless-stopped

volumes:
  timescale_data:
```

### Database Initialization

We'll create initialization scripts to:
1. Create the database schema
2. Convert tables to hypertables
3. Set up initial continuous aggregates
4. Configure compression policies

## Performance Optimization

### Query Optimization Techniques

1. **Chunk Exclusion**: Ensure queries include time predicates to leverage TimescaleDB's chunk exclusion
2. **Proper Indexing**: Create appropriate indexes based on query patterns
3. **Continuous Aggregates**: Pre-compute common aggregations
4. **Compression**: Compress historical data to reduce storage and improve scan performance

### Monitoring

We'll implement monitoring using TimescaleDB's built-in functions:

```sql
-- Monitor chunk statistics
SELECT * FROM chunk_relation_size_pretty('transactions');

-- Monitor compression statistics
SELECT * FROM hypertable_compression_stats('transactions');
```

## Implementation Plan

1. **Setup Development Environment**
   - Install Docker and Docker Compose
   - Set up .NET 8 SDK

2. **Database Setup**
   - Create Docker Compose file
   - Create database initialization scripts

3. **API Development**
   - Create .NET 8 Web API project
   - Implement Entity Framework Core models
   - Develop repositories and services
   - Implement API controllers

4. **TimescaleDB Features**
   - Implement hypertables
   - Configure continuous aggregates
   - Set up compression policies
   - Implement data retention

5. **Testing**
   - Unit tests for business logic
   - Integration tests for database operations
   - Performance testing with high-volume data

6. **Documentation**
   - API documentation with Swagger
   - Database schema documentation
   - Performance tuning guidelines
# TimescaleDB Sample Queries for Transaction Analysis

This document provides sample TimescaleDB queries for common transaction analysis scenarios. These queries demonstrate the power of TimescaleDB for time-series data analysis and can be used as a reference when implementing analytics features in your application.

## Basic Time-Series Queries

### 1. Recent Transactions with Time Range Filter

```sql
-- Get transactions from the last 7 days
SELECT *
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '7 days'
ORDER BY "CreatedAt" DESC
LIMIT 100;
```

### 2. Transactions by Account in a Time Range

```sql
-- Get transactions for a specific account in a date range
SELECT *
FROM "Transactions"
WHERE "AccountId" = '3f8e5d6a-1c2b-4d3e-9f8e-7d6a5c4b3e2d'
  AND "CreatedAt" BETWEEN '2023-01-01' AND '2023-01-31'
ORDER BY "CreatedAt" DESC;
```

## Time Bucketing and Aggregation

### 3. Daily Transaction Counts and Amounts

```sql
-- Aggregate transactions by day
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    COUNT(*) AS transaction_count,
    SUM("Amount") AS total_amount
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '30 days'
GROUP BY day
ORDER BY day DESC;
```

### 4. Hourly Transaction Patterns

```sql
-- Analyze transaction patterns by hour of day
SELECT 
    EXTRACT(HOUR FROM "CreatedAt") AS hour_of_day,
    COUNT(*) AS transaction_count,
    AVG("Amount") AS avg_amount
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '30 days'
GROUP BY hour_of_day
ORDER BY hour_of_day;
```

### 5. Weekly Aggregation by Category

```sql
-- Weekly transaction totals by category
SELECT 
    time_bucket('1 week', "CreatedAt") AS week,
    "CategoryId",
    COUNT(*) AS transaction_count,
    SUM("Amount") AS total_amount
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '3 months'
GROUP BY week, "CategoryId"
ORDER BY week DESC, total_amount DESC;
```

## Moving Averages and Trends

### 6. 7-Day Moving Average of Transaction Amounts

```sql
-- Calculate 7-day moving average for transaction amounts
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    AVG("Amount") AS daily_avg,
    AVG("Amount") OVER (
        ORDER BY time_bucket('1 day', "CreatedAt")
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS moving_avg_7day
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '30 days'
GROUP BY day, "Amount"
ORDER BY day;
```

### 7. Month-over-Month Growth Rate

```sql
-- Calculate month-over-month growth in transaction volume
WITH monthly_totals AS (
    SELECT 
        time_bucket('1 month', "CreatedAt") AS month,
        COUNT(*) AS transaction_count,
        SUM("Amount") AS total_amount
    FROM "Transactions"
    WHERE "CreatedAt" > NOW() - INTERVAL '12 months'
    GROUP BY month
)
SELECT 
    month,
    transaction_count,
    total_amount,
    LAG(total_amount, 1) OVER (ORDER BY month) AS prev_month_amount,
    CASE 
        WHEN LAG(total_amount, 1) OVER (ORDER BY month) IS NULL THEN NULL
        WHEN LAG(total_amount, 1) OVER (ORDER BY month) = 0 THEN NULL
        ELSE (total_amount - LAG(total_amount, 1) OVER (ORDER BY month)) / 
             LAG(total_amount, 1) OVER (ORDER BY month) * 100
    END AS growth_rate_percent
FROM monthly_totals
ORDER BY month DESC;
```

## Advanced TimescaleDB Features

### 8. Using Continuous Aggregates

```sql
-- Query from a continuous aggregate view instead of raw data
-- (Assumes you've created the continuous aggregate as shown in getting-started.md)
SELECT 
    bucket AS day,
    "AccountId",
    transaction_count,
    total_amount
FROM daily_transaction_summary
WHERE bucket > NOW() - INTERVAL '30 days'
ORDER BY "AccountId", day DESC;
```

### 9. First and Last Transaction per Day

```sql
-- Find first and last transaction of each day
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    "AccountId",
    (first("Amount", "CreatedAt")).amount AS first_amount,
    (first("CreatedAt", "CreatedAt")) AS first_transaction_time,
    (last("Amount", "CreatedAt")).amount AS last_amount,
    (last("CreatedAt", "CreatedAt")) AS last_transaction_time
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '7 days'
GROUP BY day, "AccountId"
ORDER BY day DESC, "AccountId";
```

### 10. Identifying Unusual Transaction Patterns

```sql
-- Find transactions that deviate significantly from account average
WITH account_stats AS (
    SELECT 
        "AccountId",
        AVG("Amount") AS avg_amount,
        STDDEV("Amount") AS stddev_amount
    FROM "Transactions"
    GROUP BY "AccountId"
)
SELECT 
    t."Id",
    t."AccountId",
    t."CreatedAt",
    t."Amount",
    s.avg_amount,
    s.stddev_amount,
    (t."Amount" - s.avg_amount) / NULLIF(s.stddev_amount, 0) AS z_score
FROM "Transactions" t
JOIN account_stats s ON t."AccountId" = s."AccountId"
WHERE ABS((t."Amount" - s.avg_amount) / NULLIF(s.stddev_amount, 0)) > 2
  AND t."CreatedAt" > NOW() - INTERVAL '30 days'
ORDER BY ABS((t."Amount" - s.avg_amount) / NULLIF(s.stddev_amount, 0)) DESC;
```

## Time-Series Forecasting

### 11. Simple Linear Trend Forecasting

```sql
-- Calculate a simple linear trend for transaction amounts
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    AVG("Amount") AS avg_daily_amount,
    regr_slope(EXTRACT(EPOCH FROM "CreatedAt"), "Amount") OVER (
        ORDER BY time_bucket('1 day', "CreatedAt")
        ROWS BETWEEN 30 PRECEDING AND CURRENT ROW
    ) AS trend_slope
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '60 days'
GROUP BY day, "CreatedAt", "Amount"
ORDER BY day DESC;
```

## Data Retention and Compression

### 12. Check Compression Status

```sql
-- Check compression status for the transactions hypertable
SELECT 
    hypertable_name,
    compression_enabled,
    compress_segmentby,
    compress_orderby
FROM timescaledb_information.hypertables
WHERE hypertable_name = 'Transactions';
```

### 13. View Chunk Information

```sql
-- View chunk information for the transactions table
SELECT 
    chunk_name,
    range_start,
    range_end,
    is_compressed
FROM timescaledb_information.chunks
WHERE hypertable_name = 'Transactions'
ORDER BY range_start DESC;
```

### 14. Manually Compress Chunks

```sql
-- Manually compress chunks older than 30 days
SELECT compress_chunk(chunk)
FROM timescaledb_information.chunks
WHERE hypertable_name = 'Transactions'
  AND range_end < NOW() - INTERVAL '30 days'
  AND NOT is_compressed;
```

## Performance Optimization

### 15. Analyze Query Performance

```sql
-- Analyze query performance with EXPLAIN ANALYZE
EXPLAIN ANALYZE
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    COUNT(*) AS transaction_count,
    SUM("Amount") AS total_amount
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '30 days'
  AND "AccountId" = '3f8e5d6a-1c2b-4d3e-9f8e-7d6a5c4b3e2d'
GROUP BY day
ORDER BY day DESC;
```

### 16. Check Index Usage

```sql
-- Check index usage statistics
SELECT 
    schemaname,
    relname,
    indexrelname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes
WHERE relname = 'Transactions'
ORDER BY idx_scan DESC;
```

## JSON Data Queries

### 17. Query JSON Metadata

```sql
-- Query transactions with specific metadata attributes
SELECT *
FROM "Transactions"
WHERE "Metadata"->>'payment_method' = 'credit_card'
  AND "CreatedAt" > NOW() - INTERVAL '7 days'
ORDER BY "CreatedAt" DESC;
```

### 18. Aggregate by JSON Attributes

```sql
-- Aggregate transactions by payment method from metadata
SELECT 
    "Metadata"->>'payment_method' AS payment_method,
    COUNT(*) AS transaction_count,
    SUM("Amount") AS total_amount
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '30 days'
  AND "Metadata"->>'payment_method' IS NOT NULL
GROUP BY "Metadata"->>'payment_method'
ORDER BY total_amount DESC;
```

## Combining with PostgreSQL Features

### 19. Window Functions with Time Buckets

```sql
-- Rank transactions by amount within each day
SELECT 
    time_bucket('1 day', "CreatedAt") AS day,
    "Id",
    "AccountId",
    "Amount",
    RANK() OVER (PARTITION BY time_bucket('1 day', "CreatedAt") ORDER BY "Amount" DESC) AS daily_rank
FROM "Transactions"
WHERE "CreatedAt" > NOW() - INTERVAL '7 days'
ORDER BY day DESC, daily_rank;
```

### 20. Cumulative Sums Over Time

```sql
-- Calculate cumulative transaction amounts by account
SELECT 
    "AccountId",
    "CreatedAt",
    "Amount",
    SUM("Amount") OVER (
        PARTITION BY "AccountId" 
        ORDER BY "CreatedAt" 
        ROWS UNBOUNDED PRECEDING
    ) AS running_total
FROM "Transactions"
WHERE "AccountId" IN (
    SELECT "AccountId" 
    FROM "Transactions" 
    GROUP BY "AccountId" 
    ORDER BY COUNT(*) DESC 
    LIMIT 5
)
AND "CreatedAt" > NOW() - INTERVAL '30 days'
ORDER BY "AccountId", "CreatedAt";
```

## Using These Queries in Your Application

These queries can be executed directly against your PostgreSQL/TimescaleDB database using:

1. **Entity Framework Core**: For simple queries or when you need to map results to C# objects
2. **Raw SQL Execution**: For complex TimescaleDB-specific queries that don't map well to EF Core

Example of executing raw SQL in your .NET application:

```csharp
// Using raw SQL for TimescaleDB-specific queries
var startDate = DateTime.UtcNow.AddDays(-30);
var accountId = Guid.Parse("3f8e5d6a-1c2b-4d3e-9f8e-7d6a5c4b3e2d");

var sql = @"
    SELECT 
        time_bucket('1 day', ""CreatedAt"") AS day,
        COUNT(*) AS transaction_count,
        SUM(""Amount"") AS total_amount
    FROM ""Transactions""
    WHERE ""CreatedAt"" > @startDate
      AND ""AccountId"" = @accountId
    GROUP BY day
    ORDER BY day DESC";

var parameters = new[] {
    new NpgsqlParameter("@startDate", startDate),
    new NpgsqlParameter("@accountId", accountId)
};

var results = await context.Set<DailyTransactionSummary>()
    .FromSqlRaw(sql, parameters)
    .ToListAsync();
```

Where `DailyTransactionSummary` is a DTO class:

```csharp
public class DailyTransactionSummary
{
    public DateTime Day { get; set; }
    public int TransactionCount { get; set; }
    public decimal TotalAmount { get; set; }
}
```

## Performance Considerations

1. **Time Predicates**: Always include time predicates in your queries to leverage TimescaleDB's chunk exclusion
2. **Indexes**: Create appropriate indexes based on your query patterns
3. **Continuous Aggregates**: Use continuous aggregates for frequently accessed aggregations
4. **Compression**: Compress historical data to reduce storage and improve scan performance
5. **Partitioning**: Consider additional partitioning strategies for very large datasets
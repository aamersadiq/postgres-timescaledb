I want to learn postgres timescale database features by building an application in .net 8 and using web api.

We can run the postgres in the docker container.

Use transactions as id, created, amount and other properties to build a application.
# Getting Started Guide

This guide provides step-by-step instructions for setting up the development environment and getting started with the PostgreSQL TimescaleDB .NET 8 Web API project.

## Prerequisites

Before you begin, ensure you have the following installed:

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [Docker Desktop](https://www.docker.com/products/docker-desktop)
- [Visual Studio 2022](https://visualstudio.microsoft.com/vs/) or [Visual Studio Code](https://code.visualstudio.com/) with C# extensions
- [Git](https://git-scm.com/downloads) (optional, for version control)

## Step 1: Set Up PostgreSQL with TimescaleDB in Docker

1. Create a `docker-compose.yml` file in your project root:

```yaml
version: '3.8'

services:
  timescaledb:
    image: timescale/timescaledb:latest-pg14
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=transactiondb
    ports:
      - "5432:5432"
    volumes:
      - timescale_data:/var/lib/postgresql/data
    restart: unless-stopped

volumes:
  timescale_data:
```

2. Start the Docker container:

```bash
docker-compose up -d
```

3. Verify the container is running:

```bash
docker ps
```

## Step 2: Create a New .NET 8 Web API Project

1. Create a new solution and project:

```bash
dotnet new sln -n TransactionApi
dotnet new webapi -n TransactionApi.WebApi
dotnet sln add TransactionApi.WebApi
```

2. Add necessary NuGet packages:

```bash
cd TransactionApi.WebApi
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package Microsoft.EntityFrameworkCore.Tools
```

## Step 3: Configure Database Connection

1. Update `appsettings.json` with the database connection string:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Database=transactiondb;Username=postgres;Password=postgres"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

## Step 4: Create Entity Models

1. Create a `Models` folder and add the following entity classes:

**Transaction.cs**:
```csharp
using System.Text.Json;

namespace TransactionApi.WebApi.Models;

public class Transaction
{
    public Guid Id { get; set; }
    public DateTime CreatedAt { get; set; }
    public decimal Amount { get; set; }
    public Guid AccountId { get; set; }
    public Guid CategoryId { get; set; }
    public string Description { get; set; }
    public JsonDocument Metadata { get; set; }
    
    // Navigation properties
    public Account Account { get; set; }
    public Category Category { get; set; }
}
```

**Account.cs**:
```csharp
namespace TransactionApi.WebApi.Models;

public class Account
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string AccountNumber { get; set; }
    
    // Navigation property
    public ICollection<Transaction> Transactions { get; set; }
}
```

**Category.cs**:
```csharp
namespace TransactionApi.WebApi.Models;

public class Category
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    
    // Navigation property
    public ICollection<Transaction> Transactions { get; set; }
}
```

## Step 5: Create Database Context

1. Create a `Data` folder and add the database context:

**AppDbContext.cs**:
```csharp
using Microsoft.EntityFrameworkCore;
using TransactionApi.WebApi.Models;

namespace TransactionApi.WebApi.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }
    
    public DbSet<Transaction> Transactions { get; set; }
    public DbSet<Account> Accounts { get; set; }
    public DbSet<Category> Categories { get; set; }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Configure Transaction entity
        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.CreatedAt).IsRequired();
            entity.Property(e => e.Amount).HasColumnType("decimal(18,2)").IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            
            // Configure relationships
            entity.HasOne(e => e.Account)
                .WithMany(a => a.Transactions)
                .HasForeignKey(e => e.AccountId)
                .OnDelete(DeleteBehavior.Restrict);
                
            entity.HasOne(e => e.Category)
                .WithMany(c => c.Transactions)
                .HasForeignKey(e => e.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
```

## Step 6: Register Services in Program.cs

Update your `Program.cs` file to register the database context:

```csharp
using Microsoft.EntityFrameworkCore;
using TransactionApi.WebApi.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
```

## Step 7: Create Initial Migration and Setup TimescaleDB

1. Create the initial migration:

```bash
dotnet ef migrations add InitialCreate
```

2. Create a SQL script to convert the transactions table to a hypertable:

Create a file named `Data/TimescaleDbSetup.sql`:

```sql
-- Convert transactions table to a hypertable
SELECT create_hypertable('"Transactions"', 'CreatedAt', 
                         chunk_time_interval => INTERVAL '1 day');

-- Create indexes for better query performance
CREATE INDEX idx_transactions_account_id ON "Transactions" ("AccountId");
CREATE INDEX idx_transactions_category_id ON "Transactions" ("CategoryId");
CREATE INDEX idx_transactions_account_created ON "Transactions" ("AccountId", "CreatedAt" DESC);

-- Create a continuous aggregate for daily transaction summaries
CREATE MATERIALIZED VIEW daily_transaction_summary
WITH (timescaledb.continuous) AS
SELECT 
    time_bucket('1 day', "CreatedAt") AS bucket,
    "AccountId",
    count(*) AS transaction_count,
    sum("Amount") AS total_amount
FROM "Transactions"
GROUP BY bucket, "AccountId";

-- Set up compression (optional - for production use)
-- ALTER TABLE "Transactions" SET (
--     timescaledb.compress,
--     timescaledb.compress_segmentby = '"AccountId"',
--     timescaledb.compress_orderby = '"CreatedAt"'
-- );

-- Add compression policy (compress data older than 30 days)
-- SELECT add_compression_policy('"Transactions"', INTERVAL '30 days');
```

3. Create a helper class to run the TimescaleDB setup script:

**TimescaleDbInitializer.cs**:
```csharp
using Microsoft.EntityFrameworkCore;
using Npgsql;
using System.Reflection;

namespace TransactionApi.WebApi.Data;

public static class TimescaleDbInitializer
{
    public static async Task InitializeTimescaleDbAsync(AppDbContext context)
    {
        // First ensure the database is created and migrations are applied
        await context.Database.MigrateAsync();
        
        // Read the SQL script from the embedded resource
        var assembly = Assembly.GetExecutingAssembly();
        var resourceName = "TransactionApi.WebApi.Data.TimescaleDbSetup.sql";
        
        using var stream = assembly.GetManifestResourceStream(resourceName);
        using var reader = new StreamReader(stream);
        var sql = await reader.ReadToEndAsync();
        
        // Execute the TimescaleDB setup script
        await using var conn = (NpgsqlConnection)context.Database.GetDbConnection();
        await conn.OpenAsync();
        
        await using var cmd = new NpgsqlCommand(sql, conn);
        await cmd.ExecuteNonQueryAsync();
    }
}
```

4. Update `Program.cs` to call the initializer:

```csharp
// Add after app.Build();
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<AppDbContext>();
        await TimescaleDbInitializer.InitializeTimescaleDbAsync(context);
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while initializing the database.");
    }
}
```

## Step 8: Create API Controllers

1. Create a `Controllers` folder and add the following controller:

**TransactionsController.cs**:
```csharp
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TransactionApi.WebApi.Data;
using TransactionApi.WebApi.Models;

namespace TransactionApi.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionsController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ILogger<TransactionsController> _logger;

    public TransactionsController(AppDbContext context, ILogger<TransactionsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    // GET: api/transactions
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactions(
        [FromQuery] DateTime? from = null,
        [FromQuery] DateTime? to = null,
        [FromQuery] Guid? accountId = null)
    {
        IQueryable<Transaction> query = _context.Transactions;

        // Apply filters
        if (from.HasValue)
            query = query.Where(t => t.CreatedAt >= from.Value);
            
        if (to.HasValue)
            query = query.Where(t => t.CreatedAt <= to.Value);
            
        if (accountId.HasValue)
            query = query.Where(t => t.AccountId == accountId.Value);

        return await query
            .OrderByDescending(t => t.CreatedAt)
            .Take(100) // Limit results
            .ToListAsync();
    }

    // GET: api/transactions/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Transaction>> GetTransaction(Guid id)
    {
        var transaction = await _context.Transactions.FindAsync(id);

        if (transaction == null)
        {
            return NotFound();
        }

        return transaction;
    }

    // POST: api/transactions
    [HttpPost]
    public async Task<ActionResult<Transaction>> PostTransaction(Transaction transaction)
    {
        transaction.Id = Guid.NewGuid();
        _context.Transactions.Add(transaction);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetTransaction), new { id = transaction.Id }, transaction);
    }

    // PUT: api/transactions/5
    [HttpPut("{id}")]
    public async Task<IActionResult> PutTransaction(Guid id, Transaction transaction)
    {
        if (id != transaction.Id)
        {
            return BadRequest();
        }

        _context.Entry(transaction).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!TransactionExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // DELETE: api/transactions/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTransaction(Guid id)
    {
        var transaction = await _context.Transactions.FindAsync(id);
        if (transaction == null)
        {
            return NotFound();
        }

        _context.Transactions.Remove(transaction);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool TransactionExists(Guid id)
    {
        return _context.Transactions.Any(e => e.Id == id);
    }
}
```

## Step 9: Create an Analytics Controller

**AnalyticsController.cs**:
```csharp
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TransactionApi.WebApi.Data;
using TransactionApi.WebApi.Models;

namespace TransactionApi.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AnalyticsController : ControllerBase
{
    private readonly AppDbContext _context;

    public AnalyticsController(AppDbContext context)
    {
        _context = context;
    }

    // GET: api/analytics/daily-summary
    [HttpGet("daily-summary")]
    public async Task<ActionResult<IEnumerable<object>>> GetDailySummary(
        [FromQuery] DateTime? from = null,
        [FromQuery] DateTime? to = null,
        [FromQuery] Guid? accountId = null)
    {
        // This would typically use a continuous aggregate view in TimescaleDB
        // For simplicity, we're using EF Core here
        var query = _context.Transactions.AsQueryable();
        
        if (from.HasValue)
            query = query.Where(t => t.CreatedAt >= from.Value);
            
        if (to.HasValue)
            query = query.Where(t => t.CreatedAt <= to.Value);
            
        if (accountId.HasValue)
            query = query.Where(t => t.AccountId == accountId.Value);

        var result = await query
            .GroupBy(t => new 
            { 
                Date = t.CreatedAt.Date,
                t.AccountId
            })
            .Select(g => new
            {
                Date = g.Key.Date,
                AccountId = g.Key.AccountId,
                TransactionCount = g.Count(),
                TotalAmount = g.Sum(t => t.Amount)
            })
            .OrderBy(r => r.Date)
            .ToListAsync();

        return Ok(result);
    }

    // Additional analytics endpoints can be added here
}
```

## Step 10: Run and Test the API

1. Build and run the application:

```bash
dotnet build
dotnet run
```

2. Open a browser and navigate to `https://localhost:7001/swagger` (or the port specified in your launchSettings.json) to access the Swagger UI.

3. Use the Swagger UI to test the API endpoints.

## Step 11: Sample TimescaleDB Queries

Here are some sample TimescaleDB queries you can run directly against the database using a tool like pgAdmin or the psql command line:

### 1. Query the hypertable information:

```sql
SELECT * FROM timescaledb_information.hypertables;
```

### 2. Get transaction counts by time bucket:

```sql
SELECT time_bucket('1 day', "CreatedAt") AS day,
       count(*) AS transaction_count
FROM "Transactions"
GROUP BY day
ORDER BY day DESC;
```

### 3. Calculate moving averages:

```sql
SELECT time_bucket('1 day', "CreatedAt") AS day,
       "AccountId",
       avg("Amount") OVER (
           PARTITION BY "AccountId" 
           ORDER BY time_bucket('1 day', "CreatedAt")
           ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ) AS seven_day_moving_avg
FROM "Transactions"
ORDER BY "AccountId", day;
```

### 4. Query the continuous aggregate view:

```sql
SELECT * FROM daily_transaction_summary
ORDER BY bucket DESC;
```

## Next Steps

1. **Add Authentication**: Implement JWT authentication for API security
2. **Implement Repositories**: Create repository classes to abstract data access
3. **Add Unit Tests**: Create unit tests for controllers and business logic
4. **Implement Advanced TimescaleDB Features**:
   - Data compression
   - Retention policies
   - More complex continuous aggregates
5. **Add Monitoring**: Implement health checks and monitoring for the API and database